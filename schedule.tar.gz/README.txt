Name: Krishan Patel
-No Special Instructions for the program, run normally. There should be some warnings but it should work
-Some functionality of the Queue function were found throughout the internet to enhance the one I made for my 357 class. 
    -They were minor changes

    I hope it works! :)